package com.example.pixelmusic.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

@Composable
fun PixelMusicTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFF4DA3FF),
            background = Color(0xFF08090B),
            surface = Color(0xFF121417),
            onSurface = Color(0xFFF3F4F5),
            onSurfaceVariant = Color(0xFF9AA0A6)
        ),
        content = content
    )
}
