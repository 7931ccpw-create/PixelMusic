# Pixel Music v0.1

Pixel 10a向けのXperia Music風プレーヤー試作。

現段階ではUI/操作感の土台を先に作り、曲一覧はデモデータです。

次段階:
1. MediaStoreから実曲を取得
2. Media3/ExoPlayerで再生
3. Album Art取得
4. Queue / Playlist / Favorite
5. 8色テーマ + Album Art連動
6. 通知/ロック画面/Bluetooth
7. 音量ブースト + リミッター
